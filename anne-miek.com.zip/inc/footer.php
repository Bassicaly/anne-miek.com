	<footer id="the_footer">
		Designed and hosted at <span class="mylogo">Bolster Data Services</span>
	</footer>
</div>
</body>
</html>