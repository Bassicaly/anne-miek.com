	<nav id="top_menu">
		<ul id="navmenu">
			<li><a href="/index.php">Home</a></li>
			<li><a href="#">Osteopathie</a>
				<ul class="sub1">
					<li><a href="/hoe.php">Hoe werkt het</a>
						<ul class="sub2">
							<li><a href="/geschiedenis.php">Geschiedenis</a></li>
							<li><a href="/osteopaat.php">Osteopaat</a></li>
						</ul>
					</li>
					<li><a href="/onderzoekwatdoenwe.php">Onderzoek</a></li>
					<li><a href="/behandelingwatgebeurter.php">Behandeling</a></li>
					<li><a href="/wanneernaardeosteo.php">Klachten</a></li>
				</ul>
			</li>
			<li><a href="#">Voor wie?</a>
				<ul class="sub1">
					<li><a href="/babies.php">Babies</a></li>
					<li><a href="/kinderen.php">Kinderen</a></li>
					<li><a href="/zwangerschap.php">Zwangeren</a></li>
					<li><a href="/volwassenen.php">Volwassenen</a></li>
				</ul>
			</li>
			<li><a href="/prijzen.php">Prijzen</a></li>
			<li><a href="/anne-miek.php">Over mij</a></li>
			<li><a href="/contact.php">Contact</a></li>
		</ul>
	</nav>